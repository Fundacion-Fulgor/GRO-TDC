**Minimum Rule Set** - [README](README_minimal.md)  
**Maximum Rule Set** - [README](README_maximal.md), [MissingRules](MissingRules_maximal.md)  
